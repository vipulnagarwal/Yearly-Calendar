'use strict';

angular.module('claimsDirectives', [])
		.directive('docTypeRequired', function() {
			return {
				restrict : 'A',
				require : 'ngModel',
				link : function(scope, element, attrs, ngModelCtrl) {

					function docTypeValidator(value) {
						// console.log(value);

						if (value == undefined) {
							ngModelCtrl.$setValidity('docTypeRequired', false);
							return value;
						}

						value = value.trim();

						if (value.length == 0) {
							ngModelCtrl.$setValidity('docTypeRequired', false);
							return value;
						}

						ngModelCtrl.$setValidity('docTypeRequired', true);
						return value;
					}

					ngModelCtrl.$parsers.push(docTypeValidator);
					ngModelCtrl.$formatters.push(docTypeValidator);
				}
			}
		}).directive('datepickerLocaldate', ['$parse', function ($parse) {
	        var directive = {
	                restrict: 'A',
	                require: ['ngModel'],
	                link: link
	            };
	            return directive;

	            function link(scope, element, attr, ctrls) {
	                var ngModelController = ctrls[0];

	                // called with a JavaScript Date object when picked from the datepicker
	                ngModelController.$parsers.push(function (viewValue) {
	                	if(viewValue!=null){
	                    // undo the timezone adjustment
	                    viewValue.setMinutes(viewValue.getMinutes() - viewValue.getTimezoneOffset());
	                    // local date in ISO format
	                    return viewValue.toISOString().substring(0, 10);
	                }
	                else 
	                	return undefined;
	                });

	                // called with a 'yyyy-mm-dd' string to format
	                ngModelController.$formatters.push(function (modelValue) {
	                    if (!modelValue) {
	                        return undefined;
	                    }
	                    // date constructor will apply timezone deviations from UTC (i.e. if locale is behind UTC 'dt' will be one day behind)
	                    var dt = new Date(modelValue);
	                    // 'undo' the timezone offset again (to get the original date again)
	                    dt.setMinutes(dt.getMinutes() + dt.getTimezoneOffset());
	                    return dt;
	                });
	            }
	        }]).directive(
				'additionalDocStatusCheck',
				function() {
					return {
						restrict : 'A',
						require : 'ngModel',
						link : function(scope, element, attrs, ngModelCtrl) {

							function additionalDocStatusValidator(value) {
								// console.log(value);

								if (scope.claimDetails.additionalInfo.status == 'A'
										|| scope.claimDetails.additionalInfo.received == null
										|| scope.claimDetails.additionalInfo.received != 'Y') {
									ngModelCtrl.$setValidity(
											'additionalDocStatusCheck', false);
									if (scope.reqAdditionalInfoFlag != undefined
											&& scope.reqAdditionalInfoFlag == true) {
										ngModelCtrl.$setValidity(
												'additionalDocStatusCheck',
												true);
									}
									return value;
								}

								value = value.trim();

								if (value.length == 0) {
									ngModelCtrl.$setValidity(
											'additionalDocStatusCheck', false);
									return value;
								}

								ngModelCtrl.$setValidity(
										'additionalDocStatusCheck', true);
								return value;
							}

							ngModelCtrl.$parsers
									.push(additionalDocStatusValidator);
							ngModelCtrl.$formatters
									.push(additionalDocStatusValidator);
						}
					}
				})
		.directive(
				'diagnosisRequired',
				function() {
					return {
						restrict : 'A',
						require : 'ngModel',
						link : function(scope, element, attrs, ngModelCtrl) {
							function diagnosisValidator(value) {
								// console.log(value);
								if (value != undefined) {
									// console.log(value.id);
									if (value.id == undefined) {
										ngModelCtrl.$setValidity(
												'diagnosisRequired', false);
										return value;
									}
								}

								if (value.length == 0) {
									ngModelCtrl.$setValidity(
											'diagnosisRequired', false);
									return value;
								}

								ngModelCtrl.$setValidity('diagnosisRequired',
										true);
								return value;
							}

							ngModelCtrl.$parsers.push(diagnosisValidator);
							ngModelCtrl.$formatters.push(diagnosisValidator);
						}
					}
				})
		.directive(
				'diagnosisClicked',
				function() {
					return {
						restrict : 'A',
						require : 'ngModel',
						link : function(scope, element, attrs, ngModelCtrl) {

							function diagnosisClickValidator(value) {
								// console.log(value);
								if (scope.claimDetails.diagnosises && scope.claimDetails.diagnosises.length < 1) {

									ngModelCtrl.$setValidity(
											'diagnosisClicked', false);
									return value; 
								}
								ngModelCtrl.$setValidity('diagnosisClicked',
										true);
								return value;
							}

							ngModelCtrl.$parsers.push(diagnosisClickValidator);
							ngModelCtrl.$formatters
									.push(diagnosisClickValidator);
						}
					}
				})
		.directive(
				'serviceRequired',
				function() {
					return {
						restrict : 'A',
						require : 'ngModel',
						link : function(scope, element, attrs, ngModelCtrl) {

							function serviceValidator(value) {

								// console.log(value);
								if (value != undefined) {
									// console.log(value.id);
									if (value.id == undefined) {
										ngModelCtrl.$setValidity(
												'serviceRequired', false);
										return value;
									}
								}

								if (value.length == 0) {
									ngModelCtrl.$setValidity('serviceRequired',
											false);
									return value;
								}

								ngModelCtrl.$setValidity('serviceRequired',
										true);
								return value;
							}

							ngModelCtrl.$parsers.push(serviceValidator);
							ngModelCtrl.$formatters.push(serviceValidator);
						}
					}
				})
		.directive('serviceClicked', function() {
			return {
				restrict : 'A',
				require : 'ngModel',
				link : function(scope, element, attrs, ngModelCtrl) {

					function serviceClickValidator(value) {
						// console.log(value);
						if (scope.claimDetails.services && scope.claimDetails.services.length < 1) {

							ngModelCtrl.$setValidity('serviceClicked', false);
							return value;

							/*
							 * if (value == undefined) {
							 * ngModelCtrl.$setValidity('providerClicked',
							 * false); return value; }
							 */
						}

						ngModelCtrl.$setValidity('serviceClicked', true);
						return value;
					}

					ngModelCtrl.$parsers.push(serviceClickValidator);
					ngModelCtrl.$formatters.push(serviceClickValidator);
				}
			}
		})
		.directive(
				'providerRequired',
				function() {
					return {
						restrict : 'A',
						require : 'ngModel',
						link : function(scope, element, attrs, ngModelCtrl) {

							function providerValidator(value) {

								// console.log(value);

								if (value == undefined) {
									ngModelCtrl.$setValidity(
											'providerRequired', false);
									return value;
								}

								if (value.length == 0) {
									ngModelCtrl.$setValidity(
											'providerRequired', false);
									return value;
								}

								ngModelCtrl.$setValidity('providerRequired',
										true);
								return value;
							}

							ngModelCtrl.$parsers.push(providerValidator);
							ngModelCtrl.$formatters.push(providerValidator);
						}
					}
				})
		.directive('providerClicked', function() {
			return {
				restrict : 'A',
				require : 'ngModel',
				link : function(scope, element, attrs, ngModelCtrl) {

					function providerClickValidator(value) {
						// console.log(value);
						
						if (!(scope.claimDetails.providers) || scope.claimDetails.providers.length < 1) {
							ngModelCtrl.$setValidity('providerClicked', false);
							return value;
						}
						else {
							ngModelCtrl.$setValidity('providerClicked', true);
							return value;
						}
					}
					ngModelCtrl.$parsers.push(providerClickValidator);
					ngModelCtrl.$formatters.push(providerClickValidator);
				}
			}
		})
		.directive('stringToNumber', function() {
			return {
				require: 'ngModel',
				link: function(scope, element, attrs, ngModelCtrl) {
					ngModelCtrl.$parsers.push(function(value) {
						return '' + value;
					});
					ngModelCtrl.$formatters.push(function(value) {
						return parseFloat(value);
					});
				}
			};
		})
		.directive(
				'docQualificationRequired',
				function() {
					return {
						restrict : 'A',
						require : 'ngModel',
						link : function(scope, element, attrs, ngModelCtrl) {

							function docQualificationValidator(value) {
								// console.log(value);

								if (value == undefined) {
									ngModelCtrl.$setValidity(
											'docQualificationRequired', false);
									return value;
								}

								value = value.trim();

								if (value.length == 0) {
									ngModelCtrl.$setValidity(
											'docQualificationRequired', false);
									return value;
								}

								ngModelCtrl.$setValidity(
										'docQualificationRequired', true);
								return value;
							}

							ngModelCtrl.$parsers
									.push(docQualificationValidator);
							ngModelCtrl.$formatters
									.push(docQualificationValidator);
						}
					}
				})
			.directive(
				'docQualificationRequiredCheckBox',
				function() {
					return {
						restrict : 'A',
						require : 'ngModel',
						
						scope: {
							data : '=ngModel'
						},
						
						link : function(scope, element, attrs, ngModelCtrl) {
							
							scope.$watch('data', function(newVal, oldVal, scope) {
								validator(scope.data);
							}, true);
							
							function validator(value) {
								
								if (value.validationRules) {
									
									if (!value.validations) {value.validations = {};}
									
									var validQualification = {}
									var validRequired = false;
									
									for (var key in value.validationRules) {
										validQualification[key] = (value.validations[key]=='Y' || value.validationRules[key]!='Y');
										if (value.validations[key]=='Y') {validRequired = true;}
									}
									
									if (validRequired) {ngModelCtrl.$setValidity('docQualificationRequired', true);}
									else {ngModelCtrl.$setValidity('docQualificationRequired', false);}
									
									if (validQualification.duplicate || validQualification.error || 
											(validQualification.complete && validQualification.legible && validQualification.inforce)) {
										ngModelCtrl.$setValidity('docQualificationValid', true);}
									else {ngModelCtrl.$setValidity('docQualificationValid', false);}
								}
							}
						}
					}
				})
			.directive('compareDateValidator',
				['$filter', function($filter) {
			
					var link = function(scope, element, attrs, ngModelCtrl) {
						
						scope.$watch(function() {
							return ngModelCtrl.$modelValue;}, 
							function() {dateValidator();});
						
						if (!(attrs['cdvWatchOnlyThis']==true)) {
							
							var watchedAttrs = []
							for ( var key in attrs) {
								if (key.substring(0,3) == 'cdv')
									watchedAttrs.push(key);
							}
							
							for (var n = 0; n < watchedAttrs.length; n++) {
								attrs.$observe(watchedAttrs[n], function () {
									dateValidator();});
							}
						}
						
						var dateValidator = function() {
							
							var modelValue = ngModelCtrl.$modelValue;
								
							var pastDatesStrict = [];
							var pastDatesEqual = [];
							var futureDatesStrict = [];
							var futureDatesEqual = [];
							
							/*strict: strictly greater/less than; equals: equal to or less/greater than*/
														
							for ( var key in attrs) {
								if (key.substring(0,3) == 'cdv') {
									
									var dateValue;
									
									if (attrs[key]) {dateValue = moment(attrs[key].replace(/\"/g, '')).toDate();}
									else {dateValue = null;}
									
									var dateArrayObj = {
										attr : key,
										value : dateValue
									};
									
									if (key.substring(3, 14) == 'AfterStrict')
										pastDatesStrict.push(dateArrayObj);
									if (key.substring(3, 14) == 'AfterEquals')
										pastDatesEqual.push(dateArrayObj);
									if (key.substring(3, 15) == 'BeforeStrict')
										futureDatesStrict.push(dateArrayObj);
									if (key.substring(3, 15) == 'BeforeEquals')
										futureDatesEqual.push(dateArrayObj);
								}
							}
							
							for (var n = 0; n < pastDatesStrict.length; n++) {
								if ((modelValue && pastDatesStrict[n].value) && !(moment(modelValue).isAfter(pastDatesStrict[n].value, 'day'))) 
									{ ngModelCtrl.$setValidity(pastDatesStrict[n].attr, false);}
								else { ngModelCtrl.$setValidity(pastDatesStrict[n].attr, true);}
							}
							
							for (var n = 0; n < pastDatesEqual.length; n++) {
								if ((modelValue && pastDatesEqual[n].value) && !(moment(modelValue).isSameOrAfter(pastDatesEqual[n].value, 'day'))) 
									{ ngModelCtrl.$setValidity(pastDatesEqual[n].attr, false);}
								else { ngModelCtrl.$setValidity(pastDatesEqual[n].attr, true);}
							}
						
							for (var n = 0; n < futureDatesStrict.length; n++) {
								if ((modelValue && futureDatesStrict[n].value) && !(moment(modelValue).isBefore(futureDatesStrict[n].value, 'day'))) 
									{ ngModelCtrl.$setValidity(futureDatesStrict[n].attr, false);}
								else { ngModelCtrl.$setValidity(futureDatesStrict[n].attr, true);}
							}
							
							for (var n = 0; n < futureDatesEqual.length; n++) {
								if ((modelValue && futureDatesEqual[n].value) && !(moment(modelValue).isSameOrBefore(futureDatesEqual[n].value, 'day'))) 
									{ ngModelCtrl.$setValidity(futureDatesEqual[n].attr, false);}
								else { ngModelCtrl.$setValidity(futureDatesEqual[n].attr, true);}
							}
							
						}
					}
					
					return {
						require : 'ngModel',
						link : link
					};
				} 
			])
			
			.directive('bpmRole', 
				[ '$filter', '$compile', '$timeout', 'validationRules', 
				function($filter, $compile, $timeout, validationRules) {

				var link = function(scope, element, attrs, ngModelCtrl) {
			
					var fieldRuleSet = validationRules.getFieldRuleSet();
			
					var activity = attrs['bpmRole'];
					
					var field = attrs['ngModel'];
					if (field == undefined)
						field = attrs['name'];
			
					// apply editable rule
					
					if (fieldRuleSet[activity] && fieldRuleSet[activity][field]) {
						if (fieldRuleSet[activity][field]['edit'] == false) {
							if (element[0].type == 'text' || element[0].type == 'email' || element[0].type == 'number')
								element.attr('readonly', true);
							else
								element.attr('disabled', true);
						}
						
						if (fieldRuleSet[activity][field]['min'] == false){
							element.removeAttr('min');
						}
						
						// apply required rule
						if (ngModelCtrl && fieldRuleSet[activity][field]['req'] == true) {
							
							attrs.required = true;
							ngModelCtrl.$validators.required = function(modelValue, viewValue) {
								return !attrs.required || !ngModelCtrl.$isEmpty(viewValue);
							};
							attrs.$observe('required', function() {
								ngModelCtrl.$validate();
							});
												      
							element.closest('.bpmr-elem').addClass('required');
						}
						
						if (fieldRuleSet[activity][field]['hide']) {
							element.closest('.bpmr-elem').addClass('ng-hide');							
						}
					}
			
					element.removeAttr('bpm-role');
				}
				
				return {
					require : '?ngModel',
					link : link
				};
				
				} 
			])